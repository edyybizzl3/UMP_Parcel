<?php
	include "db_connect.php";

?>

<!doctype html>
<html lang="en">
  <head>
  	<title>Tracking</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
		
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>

    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Active List Tracking</center></h2>
		<div class="card-body">
		<div class="container-fluid jumbotron">
			<form action="" method="post">
				<div class="row">
				<div class="col-md-4">
					<select name="goods_type" id="goods_type">
					<option value="parcel">Parcel</option>
					<option value="mail">Mail</option>
					<br><br>
					</select>
				</div>
					<div class="col-md-4">
						<input type="submit" class="form-control" value="Search" name="search">
					</div>
				</div>
				<br><br>
				<div class="col-lg-12">
			<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Tracking ID</th>
					<th>Type Of Goods</th>
					<th>Status</th>
				</tr>
			</thead>
			<tbody>
				<?php
				
					if(isset($_POST['search'])) {
						$goods_type = $_POST['goods_type'];
						
						$sql = "SELECT * from active_list WHERE goods_type='$goods_type'";
						$result = $conn->query($sql);
						
						if (mysqli_num_rows($result) > 0) {

							while ($row = $result-> fetch_assoc()) {
						
								echo "<tr><td>". $row["tracking_id"] . "</td><td>". $row["goods_type"]. "</td><td>". $row["status"].  "</td></tr>";
							}
							echo "</tbody></table>";
							}
							else {
								echo "0 result";
							}
							
						}
						include "chart_activelist.php";
				?>
        </tbody>
		</form>
      </div>
		</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>