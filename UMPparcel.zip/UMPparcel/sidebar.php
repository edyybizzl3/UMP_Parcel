<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">Toggle Menu</span>
	        </button>
        </div>
	  		<h1><center><img src="/UMPparcel/img/UMP-PMS.png" height="100px"></center><a href="UMP-PMS info.php" class="logo">UMP Parcel</a></h1>
        <ul class="list-unstyled components mb-5">
          <li class="active">
            <a href="StudentHomepage.php"><span class="fa fa-home mr-3"></span> Home</a>
          </li>
		  <li>
            <a href="ParcelChecking.php"><span class="fa fa-cube mr-3"></span>Parcel Checking</a>
          </li>
          <li>
            <a href="ParcelInfo.php"><span class="fa fa-sticky-note mr-3"></span>Parcel Info</a>
				<ul class="nav-pills nav-stacked" style="list-style-type:none;">
					<li>
						<a href="ParcelRecord.php"><span class="fa fa-server mr-3"></span>Record</a>
					</li></ul>
          </li>
		 
          <li>
            <a href="complaintlist.php"><span class="fa fa-paper-plane mr-3"></span>Complaint</a>
			<ul class="nav-pills nav-stacked" style="list-style-type:none;">
			<li>
						<a href="viewcomplaint.php"><span class="fa fa-eye mr-3"></span>View Complaint</a>
					</li></ul>
          </li>
		  <li>
            <a href="std_QRcode.php"><span class="fa fa-home mr-3"></span>Scan QR Code to UMP official portal</a>
		  </li>
		  <li>
            <a href="Logout.php"><span class="fa fa-home mr-3"></span> Logout</a>
		  </li>
		  </li>
        </ul>