<?php include("db_connect.php"); ?>

<!doctype html>
<html lang="en">
  <head>
  	<title>Update User</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>

        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>User Information</center></h2>
		<div class="col-lg-12">
		<div class="card card-outline card primary">	
		<div class="card-body">
		<table class="table table-striped table-hover table-bordered" id="list">
		
<?php
			$number=$_GET['number'];
			
			$sql="SELECT * FROM user WHERE number=$number";
			
			$res=mysqli_query($conn,$sql);
			
			if($res==TRUE)
			{
				$count=mysqli_num_rows($res);
				
				if($count==1)
				{
					//echo "User Available";
					$row=mysqli_fetch_assoc($res);
					
					$userID=$row['id'];
					$name=$row['name'];
					$email=$row['email'];
					$phoneNUM=$row['phone_no'];
					$address=$row['address'];
				}
				else
				{
					header("location:userlist.php");
				}
			}		
?>

		<form action=" " method="POST">
		<table class="table table-striped table-bordered table-hover">
						
			<tr>
				<th>Name</th>
				<td><input type="text" id="name" name="name" value="<?php echo $name; ?>"></td>
			</tr>
			<tr>
				<th>ID</th>
				<td><input type="text" id="id" name="id" value="<?php echo $userID; ?>"></td>
			</tr>
			<tr>
				<th>Phone Number</th>
				<td><input type="text" id="phone_no" name="phone_no" value="<?php echo $phoneNUM; ?>"></td>
			</tr>
			<tr>
				<th>Address</th>
				<td><textarea id="address" name="address" rows = "4" cols = "50"><?php $sql="SELECT * FROM user"; $address=$row['address']; echo $address;?></textarea></td>
			</tr>
			<tr>
				<th>Email</th>
				<td><input type="text" id="email" name="email" value="<?php echo $email; ?>"></td>
			</tr>
			<tr>
				<td colspan="5" style="text-align:right;">
				<input name="submit" type="submit" value="Update">
				</td>
			</tr>
			
<?php
	//check the submit button is clicked or not
	if(isset($_POST['submit']))
	{
	if(count($_POST)>0) 
	{
	mysqli_query($conn,"UPDATE user set id='" . $_POST['id'] . "', name='" . $_POST['name'] . "', phone_no='" . $_POST['phone_no'] . "', address='" . $_POST['address'] . "' ,email='" . $_POST['email'] . "' WHERE number='" . $_GET['number'] . "'");
	echo $message = "User updated successfully.";
	//header("location:userlist.php");
    }
	}
?>
		<tbody>	
		</form>
		
	  </div>
      </div>
	  </div>
	  </div>
	  </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>