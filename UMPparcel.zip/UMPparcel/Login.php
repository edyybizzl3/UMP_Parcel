<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">
		function setFocus(){
    		document.getElementById("user").focus();
		}

		function Blank_Validator(){
			if (document.login.user.value == "" ) 
			{
     			alert("Please fill the user name.");
   				document.login.user.focus();
  				return (false);
			}
			else  if (document.login.password.value == ""  ){
 				alert("Please fill the password.");
   				document.login.user.focus();
     			return (false);
			}
			return (true);
		}
</script>
<style>

body
{ 
font: 14px; 
font-family: 'Numans', sans-serif;
background: linear-gradient(rgba(0,0,0,.5), rgba(0,0,0,.5)), url('https://mygreen.ump.edu.my/images/Gallery/TRANQUILITY_BY_THE_LAKE/_NFL904221.JPG');
background-size: cover;
background-repeat: no-repeat;
color: white;
height: 100%;
width: 20%; 
margin: auto; 
padding: 200px;
}
         
label 
{
font-weight:bold;
font-size:14px;
color: white; 
width:100px;
}

</style>

</head>
<?php 
$conn= new mysqli('localhost','root','','umpparcel')or die("Could not connect to mysql".mysqli_error($con));

	if (isset($_REQUEST['submit'])) {
		$userID = $_REQUEST["id"];
		$password = $_REQUEST["password"];

		if ($_REQUEST['user_type'] == 'student') {
			$sql="select * from user where id='$userID' AND password='$password' AND user_type='student'" or die (mysqli_error());
			$res=mysqli_query($conn,$sql);
			mysqli_store_result($conn);
			$count_row=mysqli_num_rows($res);
			$row=mysqli_fetch_array($res);

			if ($count_row > 0) {
        session_start();
        $_SESSION['log'] = TRUE;
   		$_SESSION['userID']=$row['id'];
        $_SESSION['id']=$userID;
 				echo $message =  "<script language=javascript>  location.href='StudentHomepage.php' </script>";
			}
			else{
				echo $message=  "<script language=javascript> 
        alert(\"Sorry Invalid Student User Name and Password Please Try Again.\");</script>";
      }
        mysqli_free_result($res);
    	}
		
   	else if ($_REQUEST['user_type'] == 'admin') {
   		$sql1="select * from user where id='$userID' AND password='$password' AND user_type='admin'" or die (mysqli_error());
			$res1=mysqli_query($conn,$sql1);
			mysqli_store_result($conn);
			$count_row1=mysqli_num_rows($res1);
			$row1=mysqli_fetch_array($res1);
   		if ($count_row1 > 0) {
        session_start();
        $_SESSION['log'] = TRUE;
   		$_SESSION['userID']=$row1['id'];
        $_SESSION['id']=$userID;
 				echo $message =  "<script language=javascript>  location.href='AdminHomepage.php' </script>";
   			}
			else{
				echo $message=  "<script language=javascript> 
        alert(\"Sorry Invalid Administrator User Name and Password Please Try Again.\");</script>";
      }
       mysqli_free_result($res1);
   	}

   	else if ($_REQUEST['user_type'] == 'officer') {
   		$sql2="select * from user where id='$userID' AND password='$password'  AND user_type='officer'" or die (mysqli_error());
			$res2=mysqli_query($conn,$sql2);
			mysqli_store_result($conn);
			$count_row2=mysqli_num_rows($res2);
			$row2=mysqli_fetch_array($res2);
   		if ($count_row2 > 0) {
        session_start();
        $_SESSION['log'] = TRUE;
		$_SESSION['userID']=$row2['id'];
        $_SESSION['id']=$userID;
		
 				echo $message =  "<script language=javascript>  location.href='AdminHomepage.php' </script>";
			}
			else{
				echo $message=  "<script language=javascript> 
        alert(\"Sorry Invalid Officer User Name and Password Please Try Again.\");</script>";
      }
       mysqli_free_result($res2);    
    	} 

      mysqli_close($conn);     
	}
?>
<body onload="setFocus()">
      
	  <div align = "center">
         
		 <div style = "width:300px; border: solid 5px white; " align="left" >	
            
			<div style = "margin:30px">
			
               <h1>UMP Parcel</h1>
			   
				<form action="" method="post">
				
				<label>UserName :</label><br>
				<input id="id" name="id" type="text"><br><br>

				<label>Password :</label><br>
				<input id="password" name="password" type="password"><br><br>
				
				<label>User Type </label><br>
				<td><select id="user_type" name= "user_type">
				<option value="student"> student </option>
				<option value="officer"> officer </option>
				<option value="admin"> admin </option>
				</select><br><br>
			
				<input name="submit" type="submit" value="Login">
				<input name="reset" type="reset" value="Reset"><br><br>

				</form>
               
               <div style = "font-size:11px; color:#cc0000; margin-top:10px"></div>
					
            </div>
				
         </div>
			
      </div>
</body>
</html>