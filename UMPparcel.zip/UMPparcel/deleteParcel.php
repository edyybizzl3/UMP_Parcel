<?php
include ("db_connect.php");


    $tracking_id = $_GET['tracking_id'];
    $sql="DELETE FROM collected_list WHERE status= 'Receive' Limit 1 ";

    $res= mysqli_query($conn,$sql);

    //check the query executed or not
   if($conn-> query($sql)){
	
	$message = "Delete Successfull!";
            echo "<script type='text/javascript'>alert('$message');
            </script>";
			}
			
	$insertGoTo = 'viewcollectedInfo.php';
	if (isset($_SERVER['QUERY_STRING'])) {
	$insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
	}
	header(sprintf("Location: ".$insertGoTo));
		?>