<?php include("db_connect.php"); ?>

<!doctype html>
<html lang="en">
  <head>
  	<title>Search User</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>

        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5 pt-5">
		<h2 class="mb-4"><center>Search User Information</center></h2>
		<div class="col-lg-12">
		<div class="card card-outline card primary">	
		<div class="card-body">
			<table class="table table-striped table-hover table-bordered" id="list">
		
	    <form action=" " method="post">
        	<table class="table table-striped table-bordered table-hover">
        	<tr>
        		<td>Please Search by User Name:  </td>
            	<td><input type="text" name="name"></td>
            	<td colspan="3"><button type="submit" name="search">Search</td>
            </tr>
			</tbody>
	    </form>

<table class="table table-striped table-bordered table-hover">

	<?php
	
    echo "<tr>";	
	echo "<th>"."ID"."</th>";
	echo "<th>"."Name"."</th>";
	echo "<th>"."Email"."</th>";
	echo "<th>"."Phone Number"."</th>";
	echo "<th>"."Address"."</th>";
	echo "<th>"."User Type"."</th>";
	
		if(isset($_POST['search']))
		{
        $name = $_POST['name'];
        $sql = "SELECT * FROM user WHERE name = '$name' "; 
        $result = $conn-> query($sql);

		while($row = mysqli_fetch_assoc($result))
		{
				
						?>
							<tr>
							<td><?php echo $row["id"]; ?></td>
							<td><?php echo $row["name"]; ?></td>
							<td><?php echo $row["email"]; ?></td>
							<td><?php echo $row["phone_no"]; ?></td>
							<td><?php echo $row["address"]; ?></td>
	                        <td><?php echo $row["user_type"]; ?></td>
	                        </tr> 
						
						<?php
						}
					}
				else 
				{
				echo "No results found.";
				}	
				?>
				
	  </div>
      </div>
	  </div>
	  </div>
	  </div>
	  
</tbody>
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>	