<?php
	 include "db_connect.php";
	 
		$active_id = $_GET['active_id'];

		
		 
		$sql = "DELETE FROM active_list WHERE active_id='$active_id'";
		
		if ($conn-> query($sql)){
			$message = "Delete successfull!";
            echo "<script type='text/javascript'>alert('$message');
            </script>";
			}


	$insertGoTo = 'viewactivelist.php';
	if (isset($_SERVER['QUERY_STRING'])) {
	$insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
	}
	header(sprintf("Location: ".$insertGoTo));
		 ?>