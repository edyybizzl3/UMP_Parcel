<?php include("db_connect.php"); ?>

<!doctype html>
<html lang="en">
  <head>
  	<title>Add User</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>

        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>User Information</center></h2>
		<div class="col-lg-12">
		<div class="card card-outline card primary">	
		<div class="card-body">
			<table class="table table-striped table-hover table-bordered" id="list">
		
		<?php
			if(isset($_SESSION['add'])){
				echo $_SESSION['add'];//Display message
				unset($_SESSION['add']);//Remove message
			}
		?>
		
		<form action=" " method="POST">
		<table class="table table-striped table-bordered table-hover">
						
			<tr>
				<th>Name</th>
				<td><input type="text" id="name" name="name"></td>
			</tr>
			<tr>
				<th>ID</th>
				<td><input type="text" id="id" name="id"></td>
			</tr>
			<tr>
				<th>Phone Number</th>
				<td><input type="text" id="phone_no" name="phone_no"></td>
			</tr>
			<tr>
				<th>Address</th>
				<td><textarea id="address" name="address" rows = "4" cols = "50"></textarea></td>
			</tr>
			<tr>
				<th>Email</th>
				<td><input type="text" id="email" name="email"></td>
			</tr>
			<tr>
				<th>Password</th>
				<td><input type="password" id="password" name="password"></td>
			</tr>
			<tr>
				<th>User Type</th>
				<td><select name= "user_type[]">
				<option> student </option>
				<option> officer </option>
				<option> admin </option>
			</select></td>
			</tr>
			<tr>
				<td colspan="5" style="text-align:right;">
				<input name="submit" type="submit" value="Add">
				<input type="reset" value="Reset">
				</td>
			</tr>
		<?php
	
	//Process value from form
	//check whether the button is clicked or not
	
	if(isset($_POST['submit']))
	{
		$userID=$_POST['id'];
		$name=$_POST['name'];
		$password=$_POST['password'];
		$email=$_POST['email'];
		$phoneNUM=$_POST['phone_no'];
		$address=$_POST['address'];
		foreach ($_POST['user_type'] as $userType)
		
		$sql="INSERT INTO user (id, name, email, password, phone_no, address, user_type)
				VALUES ('$userID', '$name', '$email', $password, '$phoneNUM', '$address', '$userType')";
		
		$res=mysqli_query($conn,$sql) or die(mysqli_error());
		
		if($res==TRUE){
		
			//create session variable
			echo "User added successfully.";
			$_SESSION['add'] = "User Added Successfully.";
			//header("location:userlist.php");
		}
		else
		{
			echo "Failed to add.";
			$_SESSION['add'] = "Failed to add user.";
			//header("location:userlist.php");
		}	
	}
	
?>	
		<tbody>	
		</form>
		
	  </div>
      </div>
	  </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>