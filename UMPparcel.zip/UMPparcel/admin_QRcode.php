<!doctype html>
<html lang="en">
  <head>
  	<title>Scan QR Code</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>
				

    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Scan QR Code to UMP official portal</center></h2>
		<?php
		include ('phpqrcode/qrlib.php');
		$link= "https://www.ump.edu.my/en";
	
		$path='images/';
		$file=$path.uniqid().".png";
	
		QRcode::png($link, $file, 'L', 5, 2);
	
		echo "<center><img src='".$file."'><center>";
		?>
		<p>Hi, you may go to UMP official portal by this qrcode above. </p>
		<p>You can also choose to click <a href="https://www.ump.edu.my/en">here</a> to UMP official portal.</p>
		<div class="col-lg-12">
        
      </div>
		</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>

