<?php include'db_connect.php'; 
$sql = "SELECT * from complaint_list";
	$result = $conn-> query($sql);
	?>
	
<!doctype html>
<html lang="en">
  <head>
  	<title>Complaint List</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>


        <!-- Page Content  -->
		 <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Complaint List</center></h2>
		<div class="col-lg-12">
		
		<div class="card card-outline card primary">	
		<div class="card-body">
			<table class="table table-striped table-hover table-bordered" id="list">
			
			<thead>
			<tr>
				<th>Complaint No.</th>
				<th>Student Name</th>
				<th>ID</th>
				<th>Tracking No.</th>
				<th>Date</th>
				<th>Complaint Type</th>
				<th>Remark</th>
				
				<th>Status</th>
				<th>Action</th>
				
			</tr>
			</thead>
		<tbody>	
			 		
		<?php
	if (mysqli_num_rows($result) > 0) {
		
		                 while($row = mysqli_fetch_assoc($result))
                        {	$complaint_id= $row['complaint_id'];
                            $student_name= $row['student_name'];
                            $student_id = $row['student_id'];
                            $tracking_id = $row['tracking_id'];
                            $date = $row['date'];
                            $type = $row['type'];
							$remarks = $row['remarks'];
                            $complaint_status = $row['complaint_status'];
							

            ?>
                            <tr>
                                <td><?php echo $complaint_id ?></td>
                                <td><?php echo $student_name ?></td>
                                <td><?php echo $student_id?></td>
                                <td><?php echo $tracking_id ?></td>
                                <td><?php echo $date ?></td> 
                                <td><?php echo $type ?></td> 
								<td><?php echo $remarks ?></td> 

                                <td><?php echo $complaint_status ?></td> 
                                <td><a href="updatecomplaintstatus.php?complaint_id=<?php echo $complaint_id ?>&student_name=<?php echo $student_name?>&student_id=<?php echo $student_id?>&tracking_id=<?php echo $tracking_id?>&date=<?php echo $date?>&type=<?php echo $type?>&remarks=<?php echo $remarks?>">UPDATE</a></td>
                              
                            </tr>
                            <?php
                        }
                    }
                            ?>
			</thead>
		<tbody>	
		<form action="updatecomplaintstatus.php" method="POST">
		
		
			<script src="js/jquery.min.js"></script>
			<script src="js/popper.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="js/main.js"></script>
	
	</body>
	<html>
	

