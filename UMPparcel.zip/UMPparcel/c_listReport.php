<?php  include'db_connect.php'; 
		
		$query = "SELECT status, count(*) as number FROM collected_list GROUP BY collection";
		$result = mysqli_query($conn, $query);
		
	?>
	

<!doctype html>
<html lang="en">
  <head>
  	<title>Collected List Report</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>


        <!-- Page Content  -->
		<div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Collected List Report</center></h2>
		<div class="col-lg-12">
		<div class="card-body">
			<table class="table tabe-hover table-bordered" id="list">
			
	<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Status', 'Number'],
		 
          <?php
		  while($row = mysqli_fetch_assoc($result))
		  {
			  echo "['".$row["status"]."',".$row["number"]."],";
		  }
		  ?>
        ]);

        var options = {
          title: 'Percentage of goods with Ready for Collection over Received',
          pieHole: 0.4,
        };

        var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="donutchart" style="width: 900px; height: 500px;"></div>
  </body>
</html>
</html>