<?php include'db_connect.php'; 
	$sql = "SELECT * FROM collected_list";
	$result = $conn-> query($sql);
	?>
<!doctype html>
<html lang="en">
  <head>
  	<title>View Collected List</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
		<onclick = "href = studentview.php">
		
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>
		
        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>View Collected Info</center></h2>
		<div class="col-lg-12">
		<div class="card card-outline card primary">	
		<div class="card-body">
		<table class="table table-striped table-bordered table-hover">
			
			<thead>
			
			<td colspan=" 6 " style="text-align:right;">
				<a href="c_searchdetails.php"><input type="submit" name="submit" value="search"></a>
			
			<tr>
			
				<th>No</th>
				<th>Tracking ID</th>
				<th>Goods Type</th>
				<th>Date</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
			</thead>
		<tbody>		
		<form action="viewcollectedInfo.php" method="res">
		<?php
	if (mysqli_num_rows($result) > 0) {
		
		                 while($row = mysqli_fetch_assoc($result))
                        {
                            $collect_id = $row['collect_id'];
							$tracking_id = $row['tracking_id'];
							$goods_type = $row['goods_type'];
                            $update_date = $row['update_date'];
							$status = $row['status'];
							
							

            ?>
                            <tr>
                                <td><?php echo $collect_id ?></td>
								<td><?php echo $tracking_id ?></td>
								<td><?php echo $goods_type ?></td>
								<td><?php echo $update_date ?></td>
                                <td class='text-center'><?php 
								switch ($status) {
									case 'Ready for Collection':
										echo "<span class='badge badge-pill badge-primary'>Ready for Collection</span>" ;
										break;
									case 'Receive':
										echo "<span class='badge badge-pill badge-success'>Receive</span>";
										break;
									}
									?></td>
								<td><button name='delete'><a href="deleteParcel.php?tracking_id=<?php echo $tracking_id ?>" onclick="return confirm('Are You Sure?');">DELETE</a></button></td>
                            </tr>
                            <?php
                        }
                    }
                            ?>


			<script src="js/jquery.min.js"></script>
			<script src="js/popper.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="js/main.js"></script>
	
	</body>
	<html>