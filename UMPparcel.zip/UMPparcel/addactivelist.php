	<?php if(!isset($conn)){ include 'db_connect.php'; } ?>
	<?php

		$fullname = $_POST['fullname'];
		$number = $_POST['number'];
		$address = $_POST['address'];
		$arrive = $_POST['arrive'];
		$goods = $_POST['goods'];
		$collected = $_POST['collected'];
		$sname = $_POST['sname'];
		$snumber = $_POST['snumber'];
		$status = $_POST['status'];
		
		//Database connection
		$conn= new mysqli("localhost","root","","web");
		
		if ($conn->connect_error) {
		  die("Connection failed: " . $conn->connect_error);
		}else {
			$stmt = $conn->prepare("Insert into activelist(fullname, number, address, arrive, goods, collected, sname, snumber, status )
					values(?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$stmt->bind_param("sssssssss", $fullname, $number, $address, $arrive, $goods, $collected, $sname, $snumber, $status);
			$stmt->execute();
			echo "Add Successfully...";
			$stmt->close();
			$conn->close();
		}

	?>