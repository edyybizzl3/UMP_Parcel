
	

<!doctype html>
<html lang="en">
  <head>
  	<title>Complaint</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "sidebar.php"; ?>
				

    	</nav>

        <!-- Page Content  -->
		<div id="content" class="p-4 p-md-5 pt-5">
	    <h2 style="text-align:center/left/right;" class="mb-4">Complaint</h2><br>
	    <div class="col-lg-12">
		<div class="card card-outline card primary">
		<div class="card-body">
		<table class="table table-striped table-hover table-bordered" id="list">
			<form action="/UMPparcel/addcomplaintlist.php" method="post">
				<input type="hidden" name="id">
		<div id="msg" class=""></div>
		<div class="row">
			<div class="col-md-6">
    
		<h4>Application Information</h4>
		
<table style="width:100%"> 
<tr>
	<td>
  <label for="student_name">Full Name:</label><br>
  <input type="text" id="student_name" name="student_name" value="Jonathan Ng Tze Herng"><br>
  <label for="student_id">Matric ID:</label><br>
  <input type="text" id="student_id" name="student_id" value="CA18111"><br>
  <label for="tracking_id">Tracking ID:</label><br>
  <input type="text" id="tracking_id" name="tracking_id" value="EF220384519028MY"><br>

</td>   
  </tr>
 
<tr>
	<td>
		<br>
	</td>
</tr>

<tr>
	<th colspan="3">Current Date & Time</th>

</tr>
  <tr>
	<td colspan="3"><p id="demo"></p>

	<script>var d = new Date();	document.getElementById("demo").innerHTML = d;</script>
    </td>
	
  </tr>
  

  
    
  <tr>
	<th colspan="3">Complaint Type</th>
  </tr>
  
	<tr>
        <td colspan="3" class = "select">Choose Category
        <select name="type"><optgroup label="Parcel"></optgroup>
                <option value="Product Damage">Product Damage</option>
                <option value="Packaging Damage">Packaging Damage</option>
                <option value="Wrong Item">Wrong Item</option>
                <optgroup label="Services"></optgroup>
				<option value="Bad Service">Bad Service</option>
				<option value="Lost Parcel">Lost Parcel</option>
				
        </select>
        </td></tr>
		
<tr>
	<td>
		<br>
	</td>
</tr>

<tr>
	<th colspan="3">Date Occured </th>
</tr>

 <tr> 
	<td>Date: <input type="date" name="date">
    
    </td>
</tr>
<tr>
	<td>
		<br>
	</td>
</tr>
<tr>
	<th colspan="3">Time Occured</th>
</tr>

 <tr> 
	<td>Time:<input type="time" name="time">
       
       
    </td>
</tr>

<tr>
	<td>
		<br>
	</td>
</tr>

<tr>
  <th colspan="3">Remark: </th>
</tr>
<tr>
	<td>
  		<textarea name="remarks" rows="4" cols="50"></textarea>
    </td>
</tr>


</table>
        <p></p>
        <p>Do note that the complaints submitted will be reviewed to further improve the quality and services of our system. Thanks for your feedback and response.  </p>
      </div>
		</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
	
		<div class="card-footer border-top border-info">
  		<div class="d-flex w-100 justify-content-center align-items-center">
  			<input type="submit" value= "Save"  name="save">
  			<input type="reset" value="Cancel">
			
  		</div>
  	</div>
	</form>
  </body>
</html>