<?php
	 include "db_connect.php";
	 
		$complaint_id = $_GET['complaint_id'];

		
		 
		$sql = "DELETE FROM complaint_list WHERE complaint_id='$complaint_id'";
		
		if ($conn-> query($sql)){
			$message = "Delete successful!";
            echo "<script type='text/javascript'>alert('$message');
            </script>";
			}


	$insertGoTo = 'viewcomplaint.php';
	if (isset($_SERVER['QUERY_STRING'])) {
	$insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
	}
	header(sprintf("Location: ".$insertGoTo));
		 ?>