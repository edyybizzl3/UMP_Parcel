<?php
		include'db_connect.php'; 
		if(isset($_POST['save'])){
		$student_name = $_POST['student_name'];
		$student_id = $_POST['student_id'];
		$tracking_id = $_POST['tracking_id'];
		$type = $_POST['type'];
		$date = $_POST['date'];
		$time = $_POST['time'];
		$remarks = $_POST['remarks'];
		

		$complaint_status = 'In Investigation';
		
		//Database connection
		
		if ($conn->connect_error) {
		  die("Connection failed: " . $conn->connect_error);
		}else {
			$sql = "INSERT INTO complaint_list (complaint_id , student_name, student_id, tracking_id, type, date, time, remarks, complaint_status) VALUES('','$student_name', '$student_id', '$tracking_id', '$type', '$date', '$time', '$remarks', '$complaint_status')";
			if ($conn-> query($sql)){
			$message = "You have submitted your complaint!";
            echo "<script type='text/javascript'>alert('$message');
            </script>";
			}
		}                                          
	
		
		}
	$insertGoTo = 'viewcomplaint.php';
		if (isset($_SERVER['QUERY_STRING'])) {
	$insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
	}
	header(sprintf("Location: ".$insertGoTo));
		?>	
