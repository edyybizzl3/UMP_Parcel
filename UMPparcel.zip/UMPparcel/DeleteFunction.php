<?php
	include "db_connect.php";
	
	$tracking_id=$_GET['tracking_id'];
	
	$sql = "DELETE FROM goods_list LIMIT 1";
	
	if($conn-> query($sql)){
	
	$message = "Delete Successfull!";
            echo "<script type='text/javascript'>alert('$message');
            </script>";
			}
			
	$insertGoTo = 'ParcelRecord.php';
	if (isset($_SERVER['QUERY_STRING'])) {
	$insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
	}
	header(sprintf("Location: ".$insertGoTo));
		?>

