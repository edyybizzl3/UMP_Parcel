<?php
    include "db_connect.php";

    $query = "SELECT COUNT(status), status FROM goods_list GROUP BY status";
    $result = mysqli_query($conn, $query); 
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
            google.charts.load('current', {'packages':['bar']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                var data = google.visualization.arrayToDataTable([
                    ['Status', 'Total'],
                    <?php
                        while($row = mysqli_fetch_array($result)){
                            echo "['".$row['status']."', '".$row['COUNT(status)']."'],";       
                        }
                    ?>
                ]);

                var options = {
                    chart: {
                        title: 'Total parcel receive by student',
                    },
                    bars: 'vertical',
                    vAxis: {format: 'decimal'},
                    height: 250,
                    colors: ['#00FFFF']
                };
                var chart = new google.charts.Bar(document.getElementById('chart_div'));
                chart.draw(data, google.charts.Bar.convertOptions(options));
            }
        </script>
    </head>
    <body>
        <div class="card border-primary mb-3">
            <div class="card-body">
                <h5 class="card-title">Total parcel receive by student</h5>
                <div id="chart_div" style="width: 25%; height:250px"></div>
            </div>    
        </div>
        
    </body>
</html>