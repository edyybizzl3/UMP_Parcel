<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">Toggle Menu</span>
	        </button>
        </div>
	  		<h1><center><img src="/UMPparcel/img/UMP-PMS.png" height="100px"></center><a href="AdminUMP-PMS info.php" class="logo">UMP Parcel</a></h1>
        <ul class="list-unstyled components mb-5">
          <li class="active">
			<a href="AdminHomepage.php"><span class="fa fa-home mr-3"></span> Home</a>
		  </li>
		  
		   <li>
            <a href="userlist.php"><span class="fa fa-users mr-3"></span> User List</a>	
		   </li>
		  
		  <li>
            <a href="new_activelist.php"><span class="fa fa-bookmark mr-3"></span> Active List</a>
				<ul class="nav-pills nav-stacked" style="list-style-type:none;">
					<li>
						<a href="viewactivelist.php"><span class="fa fa-eye mr-3"></span>View Active Info</a>
						<a href="calc_activelist.php"><span class="fa fa-calculator"></span>Calculation Active List</a>
					</li></ul>
		  </li>
		  
		  <li>
            <a href="collectedlist1.php"><span class="fa fa-suitcase mr-3"></span> Collected List</a>
				<ul class="nav-pills nav-stacked" style="list-style-type:none;">
					<li>
						<a href="viewcollectedInfo.php"><span class="fa fa-eye mr-3"></span>View Collected Info</a>
					</li>
					<li>
						<a href="calTotalStdReceive.php"><span class="fa fa-calculator mr-3"></span>Calculate Total Receive</a>
					</li></ul>
		  </li>
		  <li>
            <a href="complaintAdmin.php"><span class="fa fa-envelope mr-3"></span>Student Complaint</a>
			
		  </li>
		  <li>
			<a><span class="fa fa-area-chart mr-3"></span> Report</a>
				<ul class="nav-pills nav-stacked" style="list-style-type:none;">
					<li>
						<a href="userReport.php"><span class="fa fa-check mr-3"></span>User Report</a>
					</li>
					
					<li>
						<a href="activelist_Report.php"><span class="fa fa-check mr-3"></span>Active List Report</a>
					</li>
					
					<li>
						<a href="c_listReport.php"><span class="fa fa-check mr-3"></span>Collected List Report</a>
					</li>
					<li>
						<a href="ParcelReport.php"><span class="fa fa-check mr-3"></span>Goods List Report</a>
						<ul class="nav-pills nav-stacked" style="list-style-type:none;">
					<li>
						<a href="parcelTracking.php"><span class="fa fa-check mr-3"></span>Tracking</a></ul>
					</li>
					</li>
					
					<li>
						<a href="complaintCal.php"><span class="fa fa-check mr-3"></span>Complaint Report</a>
					</li></ul>
			<li>
            <a href="admin_QRcode.php"><span class="fa fa-home mr-3"></span>Scan QR Code to UMP official portal</a>
			</li>		
			<li>
            <a href="Logout.php"><span class="fa fa-home mr-3"></span>Logout</a>
			</li>		
					
		  </li>
 