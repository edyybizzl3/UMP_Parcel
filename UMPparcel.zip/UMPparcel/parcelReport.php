<?php
	include "db_connect.php";
	
	$sql = "SELECT active_list.arrive_date, active_list.tracking_id, collected_list.update_date FROM active_list INNER JOIN collected_list ON active_list.tracking_id=collected_list.tracking_id";
	$result = $conn-> query($sql);
?>
	
<!doctype html>
<html lang="en">
  <head>
  	<title>Parcel Report</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
		<onclick = "href = parcelReport.php">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>

    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Total Duration</center></h2>
        <div class="col-lg-12">
		<div class="card card-outline card primary">	
		<div class="card-body">
			<table class="table table-striped table-hover table-bordered" id="list">
			
			<thead>
			<tr>
				<th>Tracking id</th>
				<th>Parcel arrived date to UMP Mail Center</th>
				<th>Parcel Collected date by Student</th>
				<th>Total Duration</th>
			</tr>
			</thead>

		<tbody>	
			<form action="" method="post">
			<?php
				if (mysqli_num_rows($result) > 0) {
					while ($row = $result-> fetch_assoc()) {
						
						$start_date = strtotime($row["arrive_date"]);
						$end_date = strtotime($row["update_date"]);
			
						$totalduration = ($end_date - $start_date)/60/60/24;
						
						$tracking_id = $row['tracking_id'];
						$arrive_date = $row['arrive_date'];
						$update_date = $row['update_date'];
						
			?>			
						<tr>
							<td><?php echo $tracking_id?></td>
							<td><?php echo $arrive_date?></td>
							<td><?php echo $update_date?></td>
							<td><?php echo $totalduration?></td>
						</tr>
						<?php
					}
				}
					?>

						

      </div>
		</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>