
<?php
    include "db_connect.php";

    $query = "SELECT goods_type, count(*) as number FROM active_list GROUP BY goods_type";
    $result = mysqli_query($conn, $query); 
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
            google.charts.load("current", {packages:["corechart"]});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                var data = google.visualization.arrayToDataTable([
                    ['Type Of Goods', 'Number'],
                    <?php
                        while($row = mysqli_fetch_assoc($result)){
                            echo "['".$row['goods_type']."', ".$row["number"]."],";       
                        }
                    ?>
                ]);

                var options = {

                        title: 'Total parcel receive by officer',
						pieHole: 0.4,
						
                };
                var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
                chart.draw(data, options);
            }
			
			
        </script>
    </head>
    <body>
	
        <div class="card border-primary mb-3">
            <div class="card-body">
                <h5 class="card-title">Total parcel receive by officer</h5>
                <div id="piechart_3d" style="width: 900px; height: 500px;"></div>

            </div> 
        </div>
        
    </body>
</html>