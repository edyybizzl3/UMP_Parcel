<?php 
$conn= new mysqli('localhost','root','','umpparcel')or die("Could not connect to mysql".mysqli_error($con));
	?>


<html>
<head>

<body style="background:url(bg.jpeg);background-repeat:no-repeat:background-size:100% 100%">
</body>

</html> 
