
	<?php
	 include "db_connect.php";
	 
		$active_id = $_GET['active_id'];
		$tracking_id=$_GET['tracking_id'];
		$collect_date = date("Y-m-d");
		$status = 'Collected';
		
		 
		$sql = "UPDATE active_list SET status='$status', collect_date='$collect_date', collection = 1 WHERE active_id=$active_id";
		
		if ($conn-> query($sql)){
			$message = "Update successfull!";
            echo "<script type='text/javascript'>alert('$message');
            </script>";
			}


	$insertGoTo = 'viewactivelist.php';
	if (isset($_SERVER['QUERY_STRING'])) {
	$insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
	}
	header(sprintf("Location: ".$insertGoTo));
		 ?>