<!doctype html>
<html lang="en">
  <head>
  	<title>UMP Parcel Info</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "sidebar.php"; ?>
				

    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center> UMP Parcel Management System</center></h2>
		<p>UMP Parcel Management system is a brand new system that be promote to all student and staff in UMP. This system was develop due to the problem which is student's parcel was lost or the info of the parcel was not managed propely. To  resolve the problem, this system provide a platform to staff to manage user and all the parcel that send to Pusat Mail UMP. Student also can check their parcel info by using this system.<p>
		<div class="col-lg-12">
        
      </div>
		</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>