<?php include("db_connect.php"); ?>

<!doctype html>
<html lang="en">
  <head>
  	<title>User Report</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>
		
<style>
.col-4{
	width:30%;
	background-color: lightgrey;
	margin: 1%;
	padding: 2%;
	float: left;
}

.col-5{
	width:200%;
	background-color: lightgrey;
	margin: 1%;
	padding: 2%;
	float: left;
}

</style>
<body>
	    <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Total Number User</center></h2>
		<div class="col-4 text-center">
					<?php
						$sql="SELECT * FROM user WHERE user_type='student'";
						$res=mysqli_query($conn,$sql);
						$count=mysqli_num_rows($res);
					?>
		<h1><?php echo $count; ?></h1>
		Student
		</div>
				
		<div class="col-4 text-center">
					<?php
						$sql2="SELECT * FROM user WHERE user_type='officer'";
						$res2=mysqli_query($conn,$sql2);
						$count=mysqli_num_rows($res2);
					?>
		<h1><?php echo $count; ?></h1>
		Officer
		</div>
				
		<div class="col-4 text-center">
					<?php
						$sql3="SELECT * FROM user WHERE user_type='admin'";
						$res3=mysqli_query($conn,$sql3);
						$count=mysqli_num_rows($res3);
					?>
		<h1><?php echo $count; ?></h1>
		Admin
		</div>
		
		<div class="col-5 text-center">
		<?php
        $sql4 = "SELECT user_type, count(*) as number FROM user GROUP BY user_type";
        $res4 = mysqli_query($conn, $sql4);
		?>
		<html>
		<head>
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
		<script type="text/javascript">
		google.charts.load("current", {packages:["corechart"]});
		google.charts.setOnLoadCallback(drawChart);
		function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['User_type', 'Number'],

          <?php
          while($row4 = mysqli_fetch_assoc($res4))
          {
              echo "['".$row4["user_type"]."',".$row4["number"]."],";
          }
          ?>
        ]);

        var options = {
          title: 'Percentage of user based on user type',
          pieHole: 0.4,
        };

        var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart.draw(data, options);
		}
		</script>
		</head>
		<body>
		<div id="donutchart" style="width: 450px; height: 300px;">
		</div>
		</body>
		</html>
		</div>
		</div>
						
</div>
</div>
</body>
</html>