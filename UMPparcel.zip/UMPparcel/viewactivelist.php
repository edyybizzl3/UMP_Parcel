<?php include'db_connect.php';
date_default_timezone_set("Asia/Kuala_Lumpur");
 
$sql = "SELECT * from active_list";
	$result = $conn-> query($sql);
	?>
<!doctype html>
<html lang="en">
  <head>
  	<title>Adminstartor View List</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
		<onclick = "href = studentview.php">
		
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>
		
        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>View Active List</center></h2>
		<div class="col-lg-12">
		<div class="card card-outline card primary">	
		<div class="card-body">
		<table class="table table-striped table-bordered table-hover">
			
			<thead>
			<tr>
				<th>ID</th>
				<th>Tracking ID</th>
				<th>Student ID</th>
				<th>Address</th>
				<th>Type of goods</th>
				<th>Status of goods</th>
				<th>Action</th>
			
			</tr>
			</thead>
		<tbody>	
		
		<?php
	if (mysqli_num_rows($result) > 0) {
		
		
		while ($row = $result-> fetch_assoc()) {
			
			$active_id = $row['active_id'];
			$tracking_id = $row['tracking_id'];
			$student_id = $row['student_id'];
			$phone_no = $row['phone_no'];
			$address = $row['address'];
			$arrive_date = $row['arrive_date'];
			$item = $row['item'];
			$goods_type = $row['goods_type'];
			$collect_date = $row['collect_date'];
			$sender_name = $row['sender_name'];
			$sender_no = $row['sender_no'];
			$status = $row['status'];
			?>
			
			<tr class='text-center'><td><?php echo $active_id ?></td>
			<td><?php echo $tracking_id ?></td>
			<td><?php echo $student_id ?></td>
			<td><?php echo $address ?></td>
			<td><?php echo $goods_type ?></td>
		<td><?php 
		switch ($status) {
			case 'Received':
				echo "<span class='badge badge-pill badge-info'>Received</span>" ;
				break;
			case 'Collected':
				echo "<span class='badge badge-pill badge-success'>Collected</span>";
				break;
			}
			?></td>
			<div class="d-flex w-100 justify-content-center align-items-center">
			<td>
			<button name='update'<?php if ($status == 'Collected'){?> disable <?php } ?>><a href="update_activelist.php?active_id=<?php echo $active_id ?>">Update</a></button>
			<button name='view'><a href="activelist_detail.php?active_id=<?php echo $active_id ?>">View</a></button>
			<button name='delete'><a href="delete_activelist.php?active_id=<?php echo $active_id ?>">Delete</a></button>
			</td>
			
			</div>
			</tr>
			</div>
			</div>
			</div>
			</div>

	
	<?php
		 }
	}
		 ?>
		</tbody>	
		
			<script src="js/jquery.min.js"></script>
			<script src="js/popper.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="js/main.js"></script>
	
	</body>
	<html>