<?php include("db_connect.php"); ?>

<!doctype html>
<html lang="en">
  <head>
  	<title>Search Parcel</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>

        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5 pt-5">
		<div class="col-lg-12">
		<h2>Search Parcel Information</h2>
		
	    <form action=" " method="post">
        	<table class="table table-striped table-bordered table-hover">
        	<tr>
        		<td>Please Search by Tracking ID:  </td>
            	<td><input type="text" name="name"></td>
            	<td colspan="3"><button type="submit" name="search">Search</td>
            </tr>
			</tbody>
	    </form>

<table class="table table-striped table-bordered table-hover">

	<?php
	
	if(isset($_POST['search'])){
		$search=$_POST['search'];
    echo "<tr>";	
	echo "<th>"."Tracking ID"."</th>";
	echo "<th>"."Student ID"."</th>";
	echo "<th>"."Phone number"."</th>";
	echo "<th>"."Address"."</th>";
	echo "<th>"."Item"."</th>";
	echo "<th>"."Goods type"."</th>";
	echo "<th>"."Sender name"."</th>";
	echo "<th>"."Sender number"."</th>";
	echo "<th>"."Parcel Status"."</th>";
	
	
				error_reporting(0);
				
				if(count($_POST)>0) {
					
				$tracking_id=$_POST[tracking_id];
				
				$query = mysqli_query($conn,"SELECT * FROM active_list INNER JOIN collected_list where active_list.tracking_id= collected_list.tracking_id");
				}
				
				$i=0;
				while($row = mysqli_fetch_array($query)) {
				
						?>
						
							<tr>
							<td><?php echo $row["tracking_id"]; ?></td>
							<td><?php echo $row["student_id"]; ?></td>
							<td><?php echo $row["phone_no"]; ?></td>
							<td><?php echo $row["address"]; ?></td>
							<td><?php echo $row["item"]; ?></td>
	                        <td><?php echo $row["goods_type"]; ?></td>
							<td><?php echo $row["sender_name"]; ?></td>
							<td><?php echo $row["sender_no"]; ?></td>
							<td><?php echo $row["status"]; ?></td>
	                        </tr> 
						
						<?php
					$i++;
					
					else 
					{
					echo "<div class='error'>No results found.</div>";
					}
				}					
			?>
			
	  </div>
      </div>
	  </div>
	  
</tbody>
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>	