<?php
		include'db_connect.php'; 
		
			$tracking_id=$_GET['tracking_id'];
			$goods_type=$_GET['goods_type'];
			$update_date = date("Y-m-d");
            $status ='Ready for Collection';
			
			
		$sql = "INSERT INTO collected_list (collect_id,tracking_id,goods_type,update_date,status) VALUES ('','$tracking_id', '$goods_type', '$update_date', '$status')";
		$sql1= "UPDATE active_list SET collection = 2 WHERE tracking_id='$tracking_id'";
		if ($conn-> query($sql)){
			$conn-> query($sql1);
			
			$message = "Update successfull!";
            echo "<script type='text/javascript'>alert('$message');
            </script>";
			}
		
			
			
			
			
			
	$insertGoTo = 'viewcollectedInfo.php';
		if (isset($_SERVER['QUERY_STRING'])) {
	$insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
	}
	header(sprintf("Location: ".$insertGoTo));
		?>
			
	