<!doctype html>
<html lang="en">
  <head>
  	<title>View Parcel info</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "sidebar.php"; ?>
				

    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Parcel Information</center></h2>
		<div class="container-fluid">
		<div class="col-lg-12">
		<div class="row">
		<div class="col-lg-12">
			<h4 class="page-header"> <?php echo strtoupper("Received Parcel Infomation");?></h4>
		<div class="row">
        <div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">
                        Parcel Infomation
                </div>
				<!-- /.panel-heading -->
		<br>
		<div class="panel-body">
			<div class="row">
			<div class="col-lg-12">
		<div class="form-group">
			<div class="col-lg-2">
					<label>Tracking ID: </label>
				</div>
		<br>
		<div class="form-group">
			<div class="col-lg-2">
					<label>Items: </label>
				</div>
		<br>
		<div class="form-group">
			<div class="col-lg-2">
					<label>Delivered Date: </label>
				</div>
		<br>
		<div class="form-group">
			<div class="col-lg-2">
					<label>Received Date: </label>
				</div>
		<br>
		<div class="form-group">
			<div class="col-lg-2">
					<label>Status: </label>
				</div>
			
		</div>
		</div>
		
      </div>
		</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>