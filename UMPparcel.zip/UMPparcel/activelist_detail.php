<?php include'db_connect.php';
date_default_timezone_set("Asia/Kuala_Lumpur");
	?>
<!doctype html>
<html lang="en">
  <head>
  	<title>Adminstartor View List</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
		<onclick = "href = studentview.php">
		
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>
		
        <!-- Page Content  -->
		<div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Active List Detail</center></h2>
		<div class="col-lg-12">
		<div class="card card-outline card primary">
		<div class="card-body">
				<form action="" method="post">
			<div class="row">
			<div class="col-md-12">
			<div class="callout callout-info">
		<?php
		$active_id = $_GET['active_id'];
		$sql = "SELECT * from active_list WHERE active_id = '$active_id'";
		$result = $conn-> query($sql);
		if (mysqli_num_rows($result) > 0) {

			while ($row = $result-> fetch_assoc()) {
				echo 
				"<dl>
					<dt>Tracking Number </dt>
					<dd><h4><b>". $row["tracking_id"] ."</b></h4></dd>
				</dl>
				</div>
			</div>
			</div>" ?>
			
			<div class="row">
				<div class="col-md-6">
					<div class="callout callout-info">
						<b class="border-bottom border-primary">Student Information</b><br>
						<dl>
							<dt>Student ID</dt>
							<dd><?php echo $row["student_id"] ;?></dd>
							<dt>Phone Number</dt>
							<dd><?php echo $row["phone_no"] ;?></dd>
							<dt>Address</dt>
							<dd><?php echo $row["address"] ;?></dd>
						</dl>
					</div>
					
					<div class="callout callout-info">
						<b class="border-bottom border-primary">Sender Information</b><br>
						<dl>
							<dt>Sender Name:</dt>
							<dd><?php echo $row["sender_name"] ;?></dd>
							<dt>Sender Contact:</dt>
							<dd><?php echo $row["sender_no"] ;?></dd>
						</dl>
					</div>
				</div>
				
				<div class="col-md-6">
					<b class="border-bottom border-primary">Other Information</b><br>
					<dl>
						<dt>Arrive Date</dt>
						<dd><?php echo $row["arrive_date"] ;?></dd>
						<dt>Item</dt>
						<dd><?php echo $row["item"] ;?></dd>
						<dt>Type Of Goods</dt>
						<dd><?php echo $row["goods_type"] ;?></dd>
						<dt>Collect Date</dt>
						<dd><?php echo $row["collect_date"] ;?></dd>
						<dt>Status</dt>
						<dd><?php 
								switch ($row["status"]) {
									case 'Received':
										echo "<span class='badge badge-pill badge-info'>Received</span>" ;
									break;
									case 'Collected':
										echo "<span class='badge badge-pill badge-success'>Collected</span>";
									break;
								}
			?></dd>
					</dl>
				</div>
				<div class="d-flex w-100 justify-content-center align-items-center" >
			<button class="btn btn-secondary  bg-gradient-secondary mx-2" name='update'><a href="update_activelist.php?active_id=<?php echo $active_id ?>">Update</a></button>
			<button class="btn btn-secondary  bg-gradient-secondary mx-2" name=''><a href="viewactivelist.php">Back</a></button>
		</div>
		</div>


		</div>
		</div>
		</div>
		</div>
		
	<script>
		function goBack() {
		window.history.back();
		}
	</script>
				<?php
		}}
		?>
		
		