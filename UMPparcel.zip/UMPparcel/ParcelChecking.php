<?php	
include'db_connect.php'; 
	
?>

<!doctype html>
<html lang="en">
  <head>
  	<title>Parcel Checking</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "sidebar.php"; ?>				

    	</nav>


        <!-- Page Content  -->
		<div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Parcel Checking</center></h2>
		<div class="col-lg-12">
		<div class="card card-outline card primary">	
		<div class="card-body">
			<table class="table table-striped table-hover table-bordered" id="list">

			<form action="" method="POST">
				<td colspan="7"><input type="text" name="tracking_id" placeholder="" />
				<input type="submit" name="search" value="Search">
				</form>
		<br>
			<tr>
				<th>Tracking ID</th>
				<th>Student ID</th>
				<th>Goods Type</th>
				<th>Arrived Date</th>
				<th>Sender Name</th>
				<th>Sender Number</th>
			</tr>
			<?php

	if(isset($_POST['search'])) {
		$tracking_id = $_POST['tracking_id'];
	
		$sql = "SELECT * FROM active_list WHERE tracking_id = '$tracking_id' "; 
		$result = $conn-> query($sql);

	while($row = mysqli_fetch_assoc($result))
	{
		?>
		<tr>
			<td> <?php echo $row['tracking_id']; ?> </td>
			<td> <?php echo $row['student_id']; ?> </td>
			<td> <?php echo $row['goods_type']; ?> </td>
			<td> <?php echo $row['arrive_date']; ?> </td>
			<td> <?php echo $row['sender_name']; ?> </td>
			<td> <?php echo $row['sender_no']; ?> </td>
			
		</tr>
		
		<?php
			
	}
	}

		?>
			<script src="js/jquery.min.js"></script>
			<script src="js/popper.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="js/main.js"></script>
	
	</body>
	<html>
	