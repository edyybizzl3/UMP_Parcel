<?php include'db_connect.php'; 
		$sql = "SELECT * FROM goods_list";
		$result = $conn-> query($sql);
	?>
	
<!doctype html>
<html lang="en">
  <head>
  	<title>View Parcel List</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
		<onclick = "href = studentview.php">
		
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "sidebar.php"; ?>				

    	</nav>
		
        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>View Receive List</center></h2>
		<div class="col-lg-12">
		<div class="card card-outline card primary">	
		<div class="card-body">
		<table class="table table-striped table-bordered table-hover">
			
			<thead>

			<tr>
				<th>Tracking ID</th>
				<th>Received Date</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
			
			</thead>
			
		<tbody>		
		
		<?php
	if (mysqli_num_rows($result) > 0) {
		
		                 while($row = mysqli_fetch_assoc($result))
                        {
                            $tracking_id = $row['tracking_id'];
							$receive_date = $row['receive_date'];
                            $status = $row['status'];

            ?>
                            <tr>
                                <td><?php echo $tracking_id ?></td>
								<td><?php echo $receive_date ?></td>
                                <td class='text-center'><span class='badge badge-pill badge-success'><?php echo $status ?></span></td> 
								<td><button name='delete'><a href="DeleteFunction.php?tracking_id=<?php echo $tracking_id ?>" onclick="return confirm('Are You Sure?');">DELETE</a></button></td>
                            </tr>
                            <?php
                        }
                    }
                            ?>
	
	
			
			

			<script src="js/jquery.min.js"></script>
			<script src="js/popper.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="js/main.js"></script>
	
	</body>
	<html>