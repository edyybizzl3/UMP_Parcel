<?php
		include'db_connect.php'; 
		
			$tracking_id=$_GET['tracking_id'];
			$receive_date = date('Y-m-d');
            $status ='Receive';
			
			
		$sql = "INSERT INTO goods_list (goods_id,tracking_id,status,receive_date) VALUES ('','$tracking_id','$status','$receive_date')";
		$sql1= "UPDATE collected_list SET status = 'Receive' , collection = 1 WHERE tracking_id='$tracking_id' LIMIT 1";
		if ($conn-> query($sql)){
			$conn-> query($sql1);
			
			
			$message = "Receive Successfull!";
            echo "<script type='text/javascript'>alert('$message');
            </script>";
			}
		
			
			
			
			
		
	$insertGoTo = 'ParcelRecord.php';
	if (isset($_SERVER['QUERY_STRING'])) {
	$insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
	}
	header(sprintf("Location: ".$insertGoTo));
		?>