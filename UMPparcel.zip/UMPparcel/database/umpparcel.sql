-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2021 at 01:36 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `umpparcel`
--

-- --------------------------------------------------------

--
-- Table structure for table `active_list`
--

CREATE TABLE `active_list` (
  `active_id` int(10) NOT NULL,
  `tracking_id` varchar(50) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `phone_no` int(20) NOT NULL,
  `address` varchar(60) NOT NULL,
  `arrive_date` date NOT NULL,
  `item` varchar(30) NOT NULL,
  `goods_type` varchar(30) NOT NULL,
  `collect_date` date DEFAULT NULL,
  `sender_name` varchar(50) NOT NULL,
  `sender_no` int(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `collection` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `active_list`
--

INSERT INTO `active_list` (`active_id`, `tracking_id`, `student_id`, `phone_no`, `address`, `arrive_date`, `item`, `goods_type`, `collect_date`, `sender_name`, `sender_no`, `status`, `collection`) VALUES
(5596, 'abc123', 'CA18111', 164090376, 'kk2', '2021-06-05', 'book', 'parcel', '2021-06-06', 'jon', 198765432, 'Collected', 2),
(5597, 'qwe123', 'CA18116', 17, 'kk3', '2021-06-05', 'pencil', 'parcel', '2021-06-06', 'yc', 198765432, 'Collected', 2);

-- --------------------------------------------------------

--
-- Table structure for table `collected_list`
--

CREATE TABLE `collected_list` (
  `collect_id` int(255) NOT NULL,
  `tracking_id` varchar(50) NOT NULL,
  `goods_type` varchar(30) NOT NULL,
  `update_date` date NOT NULL,
  `status` varchar(20) NOT NULL,
  `collection` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `collected_list`
--

INSERT INTO `collected_list` (`collect_id`, `tracking_id`, `goods_type`, `update_date`, `status`, `collection`) VALUES
(123597, 'abc123', 'parcel', '2021-06-06', 'Receive', 1),
(123598, 'qwe123', 'parcel', '2021-06-06', 'Ready for Collection', 0);

-- --------------------------------------------------------

--
-- Table structure for table `complaint_list`
--

CREATE TABLE `complaint_list` (
  `complaint_id` int(255) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `tracking_id` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `time` date NOT NULL,
  `remarks` varchar(50) NOT NULL,
  `complaint_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `complaint_list`
--

INSERT INTO `complaint_list` (`complaint_id`, `student_name`, `student_id`, `tracking_id`, `type`, `date`, `time`, `remarks`, `complaint_status`) VALUES
(11, 'Jonathan Ng Tze Herng', 'CA18111', 'EF220384519028MY', 'Product Damage', '2021-06-06', '0000-00-00', 'product spoil', 'Reviewed');

-- --------------------------------------------------------

--
-- Table structure for table `goods_list`
--

CREATE TABLE `goods_list` (
  `goods_id` int(50) NOT NULL,
  `tracking_id` varchar(50) NOT NULL,
  `status` varchar(20) DEFAULT NULL,
  `receive_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `goods_list`
--

INSERT INTO `goods_list` (`goods_id`, `tracking_id`, `status`, `receive_date`) VALUES
(126, 'abc123', 'Receive', '2021-06-06');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` varchar(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone_no` int(20) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  `user_type` varchar(10) NOT NULL,
  `number` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `password`, `email`, `phone_no`, `address`, `user_type`, `number`) VALUES
('CA18111', 'Jonathan ', '12345', 'jonathanngtzeherng@gmail.com', 164090376, '28-17-C, Gurney Beach Resort, Persiaran Gurney, Georgetown 1', 'student', 10),
('CA18116', 'Siong Yong Chen', '12345', 'whmico@yahoo.com', 17, '252No 35, Lorong IM 2 ,25200, Kuantan, Pahang\r\n', 'officer', 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `active_list`
--
ALTER TABLE `active_list`
  ADD PRIMARY KEY (`active_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `collected_list`
--
ALTER TABLE `collected_list`
  ADD PRIMARY KEY (`collect_id`);

--
-- Indexes for table `complaint_list`
--
ALTER TABLE `complaint_list`
  ADD PRIMARY KEY (`complaint_id`),
  ADD KEY `tracking_id` (`tracking_id`);

--
-- Indexes for table `goods_list`
--
ALTER TABLE `goods_list`
  ADD PRIMARY KEY (`goods_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `number` (`number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `active_list`
--
ALTER TABLE `active_list`
  MODIFY `active_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5598;

--
-- AUTO_INCREMENT for table `collected_list`
--
ALTER TABLE `collected_list`
  MODIFY `collect_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123599;

--
-- AUTO_INCREMENT for table `complaint_list`
--
ALTER TABLE `complaint_list`
  MODIFY `complaint_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `goods_list`
--
ALTER TABLE `goods_list`
  MODIFY `goods_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `number` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `active_list`
--
ALTER TABLE `active_list`
  ADD CONSTRAINT `active_list_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
