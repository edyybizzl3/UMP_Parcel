<?php  include'db_connect.php'; 
		
		$query = "SELECT type, count(*) as number FROM complaint_list GROUP BY type";
		$result = mysqli_query($conn, $query);
		
	?>
	

<!doctype html>
<html lang="en">
  <head>
  	<title>Complaint Report</title>

    
	<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
       ['type', 'Number'],
		 
          <?php
		  while($row = mysqli_fetch_assoc($result))
		  {
			  echo "['".$row["type"]."',".$row["number"]."],";
		  }
		  ?>
        ]);

        var options = {
          title: 'Percentage of Complaints by type of complaint. ',
          
        };
     

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="piechart" style="width: 900px; height: 500px;"></div>
  </body>
</html>
</html>