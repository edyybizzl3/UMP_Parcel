<?php include 'db_connect.php'; ?>
	<?php
		if(isset($_POST['submit'])){
		$tracking_id = $_POST['tracking_id'];
		$student_id = $_POST['student_id'];
		$phone_no = $_POST['phone_no'];
		$address = $_POST['address'];
		$arrive_date = $_POST['arrive_date'];
		$item = $_POST['item'];
		$goods_type = $_POST['goods_type'];
		$sender_name = $_POST['sender_name'];
		$sender_no = $_POST['sender_no'];
		$status = $_POST['status'];
		
	
		
		if ($conn->connect_error) {
		  die("Connection failed: " . $conn->connect_error);
		}else {
			$stmt = $conn->prepare("Insert into active_list(tracking_id, student_id, phone_no, address, arrive_date, item, goods_type, collect_date, sender_name, sender_no, status )
					values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$stmt->bind_param("sssssssssss", $tracking_id, $student_id, $phone_no, $address, $arrive_date, $item, $goods_type, $collect_date, $sender_name, $sender_no, $status);
			$stmt->execute();
			echo "Add Successfully...";
			$stmt->close();
			$conn->close();
		}
		}

	?>
<!doctype html>
<html lang="en">
<style>
  textarea{
    resize: none;
  }
</style>
  <head>
  	<title>Active List</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>
				

    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Add Active List</center></h2>
		<div class="col-lg-12">
		<div class="card card-outline card primary">
			<div class="card-body">
				<form action="" method="post">
			<div class="row">
			<div class="col-md-6">
		Tracking ID : <input type="text" name="tracking_id" required><br><br>
		Student ID : <input type="text" name="student_id" required><br><br>
		Phone Number : <input type="text" name="phone_no" ><br><br>
		Address : <input type="text" name="address" ><br><br>
		Date Goods Arive : <input type="date" name="arrive_date" ><br><br>
		Item : <input type="text" name="item"><br><br>
		<label for="goods_type">Types of goods :</label>
		<select name="goods_type" id="goods_type">
			<option value="parcel">Parcel</option>
			<option value="mail">Mail</option>
		<br><br>
		</select>
		<br><br>

			</div>
			
	<div class="col-md-6">
	Sender Name : <input type="text" name="sender_name" ><br><br>
	Sender Phone Number : <input type="text" name="sender_no" ><br><br>
	<label for="status" >Status of goods :</label>
	<select name="status" id="status">
		<option value="Received">Received</option>
	<br><br>
	</select>
	<br><br>
	</div>
	<div class="d-flex w-100 justify-content-center align-items-center" >
		<button class="btn btn-primary  bg-gradient-primary mx-2" type="submit" value="submit" name="submit">Save</button>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>

	

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>