<?php

	include("db_connect.php");
	
	$number = $_GET['number'];
	$sql="DELETE FROM user WHERE number=$number";
	
	$res= mysqli_query($conn,$sql);
	
	//check the query executed or not
	if($res==TRUE)
	{
		//echo "User deleted";
		//create session variable to display message
		$_SESSION['delete']="<div class='success'>User deleted.</div>";
		header("location:userlist.php");
	}
	else
	{
		//echo "Failed to detele user";
		$_SESSION['delete']="<div class='error'>Failed to delete user.</div>";
		header("location:userlist.php");
	}
?>