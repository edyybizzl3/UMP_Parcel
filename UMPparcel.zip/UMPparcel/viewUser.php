<?php include("db_connect.php");

$number=$_GET['number'];

$res = mysqli_query($conn,"SELECT * FROM user WHERE number=$number");
?>

<!doctype html>
<html lang="en">
  <head>
  	<title>View User</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>

        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>User Information</center></h2>
		<div class="col-lg-12">	
		<div class="card card-outline card primary">	
		<div class="card-body">
			<table class="table table-striped table-hover table-bordered" id="list">
			
		<form action=" " method="POST">
		
		<?php
				if (mysqli_num_rows($res) > 0) 
				{
					
				$i=0;
				while($row = mysqli_fetch_array($res)) 
				{
		?>
		<table class="table table-striped table-bordered table-hover">

			<tr>
				<th>Name</th>
				<td><?php echo $row['name'];?></td>
			</tr>
			<tr>
				<th>ID</th>
				<td><?php echo $row['id'];?></td>
			</tr>
			<tr>
				<th>Phone Number</th>
				<td><?php echo $row['phone_no'];?></td>
			</tr>
			<tr>
				<th>Address</th>
				<td><?php echo $row['address']; ?></textarea></td>
			</tr>
			<tr>
				<th>Email</th>
				<td><?php echo $row['email']; ?></td>
			</tr>
			<tr>
				<th>User Type</th>
				<td><?php echo $row['user_type']?></td>
			</tr>

<?php
	$i++;
	}
?>
		</tbody>
		</form>
<?php
		}
	else 
	{
	echo "No results found.";
	}	
?>
	  </div>
      </div>
	  </div>
	  </div>
	  </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>