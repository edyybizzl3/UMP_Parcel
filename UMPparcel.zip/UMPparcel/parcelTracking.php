<?php
	include "db_connect.php";

?>

<!doctype html>
<html lang="en">
  <head>
  	<title>Tracking</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
		
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>

    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Tracking</center></h2>
		<div class="card-body">
		<div class="container-fluid jumbotron">
			<form action="" method="post">
				<div class="row">
				<div class="col-md-4">
					<input type="date" class="form-control" name="start_date">
				</div>
				<div class="col-md-4">
					<input type="date" class="form-control" name="last_date">
				</div>
				<div class="col-md-4">
					<input type="submit" class="form-control" value="Search" name="search">
				</div>
				</div>
				<br><br>
				<div class="col-lg-12">
			<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Tracking id</th>
					<th>Status</th>
					<th>Received Date</th>
				</tr>
			</thead>
			<tbody>
				<?php
					if(isset($_POST['search'])) {
						$start_date = $_POST['start_date'];
						$last_date = $_POST['last_date'];
						$sql = "SELECT * from goods_list WHERE receive_date BETWEEN '$start_date' AND '$last_date' ORDER BY receive_date";
						$result = $conn->query($sql);

						if (mysqli_num_rows($result) > 0) {

							while ($row = $result-> fetch_assoc()) {
								
								$tracking_id = $row['tracking_id'];
								$status = $row['status'];
								$receive_date = $row['receive_date'];
						?>
								<tr>
									<td><?php echo $tracking_id?></td>
									<td><?php echo $status?></td>
									<td><?php echo $receive_date?></td>
								</tr>
								<?php
							}
						}
							?>
							<?php
						}
						include "ReceivedParcelChart.php";
				?>
        </tbody>
		</form>
      </div>
		</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>