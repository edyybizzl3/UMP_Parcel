<?php include'db_connect.php'; 
	$sql = "SELECT * FROM complaint_list";
	$result = $conn-> query($sql);
	?>
<!doctype html>
<html lang="en">
  <head>
  	<title>View Complaints</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
		<onclick = "href = studentview.php">
		
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>
		
        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>View Complaints Info</center></h2>
		<div class="col-lg-12">
	<div class="card card-outline card primary">	
		<div class="card-body">
			<table class="table table-striped table-hover table-bordered" id="list">
			
			<thead>
			<tr>
				<th>Complaint No.</th>
				<th>Student Name</th>
				<th>Id</th>
				<th>Tracking No.</th>
				<th>Date</th>
				<th>Complaint Type</th>
				<th>Status</th>
			
			</tr>
			</thead>
		<tbody>		
		
		<?php
	if (mysqli_num_rows($result) > 0) {
		
		while ($row = $result-> fetch_assoc()) {
			echo "<tr><td>". $row["complaint_id"] ."</td><td>". $row["student_name"] ."</td><td>". $row["student_id"] ."</td><td>". $row["tracking_id"] ."</td><td>". $row["date"] . "</td><td>". $row["type"] . "</td><td>". $row["remarks"] . "</td><td>" . $row["complaint_status"] . "</td></tr>";
			
		}
			
		echo "</tbody></table>";
	}
	else {
			echo "0 result";
	}
	?>
	
	
			
			

			<script src="js/jquery.min.js"></script>
			<script src="js/popper.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="js/main.js"></script>
	
	</body>
	<html>