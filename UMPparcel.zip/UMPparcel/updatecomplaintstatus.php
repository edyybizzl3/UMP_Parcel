<?php
		include'db_connect.php'; 
            $complaint_id= $_GET['complaint_id'];
			$student_name= $_GET['student_name'];
            $student_id = $_GET['student_id'];
            $tracking_id = $_GET['tracking_id'];
            $date = date("Y-m-d");
            $type = $_GET['type'];
			$remarks = $_GET['remarks'];
			$complaint_status ='Reviewed';
			
			
		
		$sql= "UPDATE complaint_list SET complaint_status ='Reviewed' WHERE complaint_id='$complaint_id' LIMIT 1";
		if ($conn-> query($sql)){
			
			$message = "Update successful!";
            echo "<script type='text/javascript'>alert('$message');
            </script>";
			}
		

		?>