<?php	include'db_connect.php'; 
		$sql = "SELECT * FROM active_list WHERE active_list.collection = 1"; 
				
		$result = $conn-> query($sql);
	?>
	 
<!doctype html>
<html lang="en">
  <head>
  	<title>Collected List</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">

		
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>


        <!-- Page Content  -->
		<div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>Collected List</center></h2>
		<div class="col-lg-12">
		<div class="card card-outline card primary">	
		<div class="card-body">
			<table class="table table-striped table-hover table-bordered" id="list">
			
			<thead>
			<tr>
				<th>Tracking ID</th>
				<th>Goods Type</th>
				<th>Date</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
			<?php
	if (mysqli_num_rows($result) > 0) {
		
		                 while($row = mysqli_fetch_assoc($result))
                        {
                            $tracking_id = $row['tracking_id'];
                            $goods_type = $row['goods_type'];
                            $collect_date = $row['collect_date'];
                            $status = $row['status'];

            ?>
                            <tr>
                                <td><?php echo $tracking_id ?></td>
                                <td><?php echo $goods_type ?></td>
                                <td><?php echo $collect_date ?></td>
                                <td class='text-center'><span class='badge badge-pill badge-success'><?php echo $status ?></span></td> 
                                <td><button name='notify'><a href="update_status1.php?tracking_id=<?php echo $tracking_id ?>&goods_type=<?php echo $goods_type?>">NOTIFY</a></button></td>
                              
                            </tr>
                            <?php
                        }
                    }
                            ?>
			</thead>
		<tbody>	
			 		
		
	
			<script src="js/jquery.min.js"></script>
			<script src="js/popper.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="js/main.js"></script>
	
	</body>
	<html>
	

