<?php include("db_connect.php"); ?>

<!doctype html>
<html lang="en">
  <head>
  	<title>User List</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <style>
.view{
	background-color: #5DA3FA;
	padding: 1%;
	color: white;
	text-decoration: none;
	font-weight:bold;
}

.view:hover{
	background-color: #120E43;
}

.update{
	background-color: #6AC47E;
	padding: 1%;
	color: white;
	text-decoration: none;
	font-weight:bold;
}

.update:hover{
	background-color: #66AD47;
}

.delete{
	background-color: #E6425E;
	padding: 1%;
	color: white;
	text-decoration: none;
	font-weight:bold;
}

.delete:hover{
	background-color: #B4161B;
}
 </style>
 <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<?php include "adminsidebar.php"; ?>				

    	</nav>
		
        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4"><center>User List</center></h2>
		<div class="col-lg-12">
		<div class="card card-outline card primary">	
		<div class="card-body">
			<table class="table table-striped table-hover table-bordered" id="list">
		<?php
					if(isset($_SESSION['add'])){
						echo $_SESSION['add'];//Display message
						unset($_SESSION['add']);//Remove message
					}
					
					if(isset($_SESSION['delete'])){
						echo $_SESSION['delete'];//Display message
						unset($_SESSION['delete']);//Remove message
					}
					
					if(isset($_SESSION['update'])){
						echo $_SESSION['update'];//Display message
						unset($_SESSION['update']);//Remove message
					}
					
					if(isset($_SESSION['user_not_found'])){
						echo $_SESSION['user_not_found'];//Display message
						unset($_SESSION['user_not_found']);//Remove message
					}
		?>
		<table class="table table-striped table-bordered table-hover">
			
			<thead>
			<tr>
			
				<td style="text-align:left;">
				<a href="searchUser.php"><input type="submit" name="search" value="search user"></a>
				</td>
				<td colspan=" 2 " style="text-align:right;">
				<a href="addUser.php"><input type="submit" value="add user"></a>
				</td>
			</tr>
				
			<tr>
				<th>User Name</th>
				<th>ID</th>
				<th>Action</th>
			</tr>
			</thead>
			
			<?php
					$sql="SELECT * FROM user";
					$res=mysqli_query($conn,$sql);
							
						if($res==TRUE){
						//to check have data or not
						$count=mysqli_num_rows($res);
								
						$sn=1;
								
						if($count>0){
							while($rows=mysqli_fetch_assoc($res))
								{
									$number=$rows['number'];
									$name=$rows['name'];
									$userID=$rows['id'];
									//display values in table
							        ?>
										
										<tr>
											<td><?php echo $name; ?></td>
											<td><?php echo $userID; ?></td>
											<td>
												<a href="viewUser.php?number=<?php echo $number; ?>" class="view">View</a>
												<a href="updateUser.php?number=<?php echo $number; ?>" class="update">Update</a>
												<a href="deleteUser.php?number=<?php echo $number; ?>" class="delete">Delete</a>
											</td>
										</tr>
										
										<?php
									}
								}else
							{						
						}
					}
				?>
		<tbody>		

	</div>
    </div>
	</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
  
</html>